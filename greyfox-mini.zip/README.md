# Grey Fox Mini System – overlay

Failid (kõik samasse kausta, nt GreyFox repo juurkausta):

- `mini.html` – overlay
- `mini_config.json` – hetkeseis (ainus fail, mida muudad)
- `mini_fox.webp`, `mini_glass.webp` – pildid

## Seisu uuendamine

Ava `mini_config.json` ja muuda `income` (selle kuu tulu eurodes). Salvesta/commit.
Overlay loeb faili ise uuesti iga 20 sekundi järel – OBS-is pole vaja midagi värskendada.

    "income": 455   ->  3 täis Mini't + neljas pooleldi

Kui sa ei taha eurosid avalikku faili kirjutada, kasuta `minis`:

    "minis": 3.5    (kui see on number, siis `income` ignoreeritakse)

Uus kuu: muuda `month` ja pane `income` nulli.

## Aadressid

- Täis HUD:      `.../mini.html`               (soovitatav allika suurus 1600 × 620)
- Õhuke riba:    `.../mini.html?layout=bar`    (1080 × 84)
- Story/vertikaal: `.../mini.html?layout=story` (1080 × 1240)

Overlay venib alati allika laiuse järgi, taust on läbipaistev.
Proovimiseks: `?income=455` või `?minis=11.5`, taustavärv `?bg=222222`.
